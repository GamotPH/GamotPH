enum NavItem {
  home,
  report,
  scan,
  stats,
  history,
  notifications,
  profile,
  healthCommunity,
  emergency,
  hotlines,
}
